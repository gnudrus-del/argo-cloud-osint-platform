# Argo Cloud OSINT Platform

> A self-hosted defensive OSINT platform for analysts who need sourced, auditable and privacy-aware investigations.

[![CI](https://github.com/gnudrus-del/argo-cloud-osint-platform/actions/workflows/ci.yml/badge.svg)](https://github.com/gnudrus-del/argo-cloud-osint-platform/actions/workflows/ci.yml)
[![License: Apache 2.0](https://img.shields.io/badge/License-Apache_2.0-blue.svg)](LICENSE)
[![Python 3.10+](https://img.shields.io/badge/python-3.10%2B-blue.svg)](pyproject.toml)
[![Made with Python](https://img.shields.io/badge/made%20with-python-3776ab.svg)](https://www.python.org/)

Argo runs entirely on your infrastructure. It aggregates public sources (58 native connectors, key-free and BYOK), keeps a SHA-256 audit chain of every finding, and produces reports in Markdown, JSON, PDF, STIX 2.1 and MISP formats. No telemetry, no cloud dependency, no vendor lock-in.

---

## Why Argo?

Existing OSINT SaaS tools work well until you cannot send your case data to a third-party cloud — regulated investigations, corporate due diligence, journalist source-protection, legal cases with confidentiality obligations. Argo runs on **your** machine or VM. Your leads and findings never leave your perimeter.

## Features

- **CLI + web UI** — Python CLI for scripting; a lightweight web UI (no framework runtime bloat) for case management.
- **Case-based investigations** — every query lives in a case with scope, Rules of Engagement, and DSAR (GDPR) endpoints.
- **Privacy-by-design target handling** — personal targets require an explicit legal basis; contacts are redacted by default.
- **BYOK provider model** — 15 optional providers (Shodan, VirusTotal, HIBP, SecurityTrails, etc.) use *your* API keys, never intermediated.
- **58 native connectors** — 43 key-free (crt.sh, RDAP, DNS, TLS certs, Wayback, Gravatar, GDELT, Nominatim, PhishTank, holehe, maigret, subdomain enumeration, and more) + 15 BYOK.
- **Sourced findings** — every finding carries evidence URLs, timestamps and confidence scoring.
- **Audit chain (SHA-256)** — every event (login, search, finding, deletion) is appended to a hash-chained log. Tampering with a past event invalidates every subsequent hash. Same pattern as Certificate Transparency and Git.
- **Markdown / JSON / PDF exports** — for analyst reports.
- **STIX 2.1 bundle + MISP event exports** — for TIP integration.
- **Connector/plugin architecture** — add a new source by implementing a small `BaseConnector` subclass.
- **Docker + self-hosted deployment** — includes `Dockerfile`, `docker-compose.yml`, systemd unit, and a Caddy reverse-proxy recipe.

## Use cases

- **Defensive domain reconnaissance** — understand your own attack surface before an attacker does.
- **Corporate due diligence** — verify partners/vendors with sourced evidence.
- **Threat intelligence enrichment** — correlate observables (IPs, hashes, domains, wallets) with public feeds and your own MISP.
- **Authorized username / email / domain investigations** — with legal-basis gating and consent tracking.
- **Analyst reporting** — reproducible reports with audit chain for court-ready evidence.

## What Argo does *not* do

Argo is a **defensive** tool. It refuses to be a weapon.

- **No doxxing.** Personal-target investigations require explicit legal basis and produce redacted output by default.
- **No stalking.** Continuous monitoring of individuals is not offered.
- **No login bypass, credential stuffing, or account takeover assistance.**
- **No aggressive scraping.** All connectors respect rate limits and `robots.txt`.
- **No unauthorized scans.** Active recon (port scan, content discovery) requires an in-scope case and produces audit evidence.
- **No private-data purchase or "leak" resale enrichment.** BYOK integrations to HIBP/similar are for verification of *user-owned* accounts, not mass lookup.

---

## Quickstart (5 minutes)

### Local install

```bash
git clone https://github.com/gnudrus-del/argo-cloud-osint-platform.git
cd argo-cloud-osint-platform
python -m venv .venv
# Linux/macOS: source .venv/bin/activate
# Windows PowerShell: .\.venv\Scripts\Activate.ps1
pip install -e .
```

### Run the CLI

```bash
argo-osint example.com --type domain --provider none --max-pages 1 \
    --output-dir reports/smoke --format both
```

### Run the web UI

```bash
export OSINT_WEB_TOKEN="pick-a-long-random-token"
python -m osint_bot.web --host 127.0.0.1 --port 8000
# open http://127.0.0.1:8000
```

### Run with Docker

```bash
export OSINT_WEB_TOKEN="pick-a-long-random-token"
docker compose up --build
```

Full walkthrough: [`docs/QUICKSTART.md`](docs/QUICKSTART.md).

---

## Examples

Domain investigation, no API keys required:

```bash
argo-osint example.com --type domain --provider none \
    --output-dir reports/example --format both
```

Domain investigation with providers (BYOK):

```bash
export SHODAN_API_KEY=...
export VIRUSTOTAL_API_KEY=...
argo-osint example.com --type domain --provider all \
    --output-dir reports/example-full --format both
```

Company investigation:

```bash
argo-osint "Acme Corp" --type company --provider all \
    --output-dir reports/acme --format both
```

Authorized username investigation (requires case with legal basis):

```bash
argo-osint alice.example --type username --case-id CASE-2026-001 \
    --output-dir reports/case-001 --format both
```

More: [`docs/EXAMPLES.md`](docs/EXAMPLES.md).

---

## Architecture at a glance

```mermaid
flowchart LR
    CLI[CLI: argo-osint] --> ORCH
    WEB[Web UI :8000] --> ORCH[Orchestrator]
    ORCH --> REG[Connector Registry]
    REG --> C1[crt.sh]
    REG --> C2[RDAP / DNS / TLS]
    REG --> C3[Shodan · VT · HIBP · ...]
    REG --> C4[holehe / maigret / theHarvester]
    REG --> Cn[+ 50 more]
    ORCH --> STORE[(SQLite / Postgres)]
    ORCH --> AUDIT[(SHA-256 audit chain)]
    STORE --> EXPORT[Exports: MD / JSON / PDF / STIX 2.1 / MISP]
    EXPORT --> REPORT[Analyst report]
```

Details: [`docs/ARCHITECTURE.md`](docs/ARCHITECTURE.md).

---

## Plugin / connector architecture

A connector implements one small interface (`BaseConnector`) that takes a target and returns `Finding` objects with evidence URLs and confidence. A connector declares:

- **Input types** it accepts (domain, ip, email, handle, phone, wallet, …).
- **Action class** — `passive` (public data only), `active` (touches target), or `intrusive` (gated).
- **Rate limit** — per-minute, per-day and burst.
- **Legal note** — human-readable summary of what data it exposes and when it should not be used.
- **Optional key** — `required_key` names an env var; if unset, the connector reports `missing_key` cleanly.

Add a new source in ~50 lines. See [`docs/CONNECTORS.md`](docs/CONNECTORS.md).

---

## Security and responsible use

Argo is built for authorized investigations. Reading data about a person you have no legal basis to investigate is **your** legal problem, not Argo's — but Argo tries to make the right thing the easy thing.

- **Security model:** [`docs/THREAT_MODEL.md`](docs/THREAT_MODEL.md)
- **Responsible use guide:** [`docs/RESPONSIBLE_USE.md`](docs/RESPONSIBLE_USE.md)
- **Vulnerability disclosure:** [`SECURITY.md`](SECURITY.md)

### Security model (short version)

- Runs entirely local / self-hosted. Assumed threat model: single-tenant analyst on a trusted machine or VM.
- **BYOK.** Argo does not intermediate third-party APIs. Your keys, your rate quota, your invoice.
- **No hardcoded secrets.** All configuration via env vars; `.env.example` is documented; `.gitignore` blocks `.env`, `*.env`, `secrets.env`, `deploy_artifacts/`.
- **Target data at rest** is stored under case scope in SQLite (default) or Postgres. Encryption-at-rest is currently **not** applied — treat the datastore as sensitive and use OS-level disk encryption. Tracked as a roadmap item.
- **Audit chain (SHA-256)** for tamper-evidence. Full-chain verification is a single CLI command.
- **DSAR (GDPR):** deletion and export endpoints are implemented.

---

## Roadmap

See [`docs/ROADMAP.md`](docs/ROADMAP.md). Highlights of the near-term plan:

- **Planned:** connector-key encryption at rest.
- **Planned:** publish Docker image to GHCR.
- **Planned:** first PyPI release under name `argo-cloud-osint`.
- **Experimental:** AI enrichment (`ai` extra) — OCR + NER + language detection.
- **In progress:** Next.js web frontend (`web-next/`) for richer graph visualization.

---

## Contributing

Contributions welcome. Please read [`CONTRIBUTING.md`](CONTRIBUTING.md) and [`CODE_OF_CONDUCT.md`](CODE_OF_CONDUCT.md) before opening a PR.

For questions or ideas, open a [discussion](https://github.com/gnudrus-del/argo-cloud-osint-platform/discussions).

---

## Star the project

If Argo helps your OSINT workflow, consider starring the repository so other analysts can find it. It is the single most useful thing you can do to support the project without writing code.

---

## License

Apache License 2.0 — see [`LICENSE`](LICENSE).

---

## Documentazione in italiano

Vedi [`docs/README.it.md`](docs/README.it.md) per la versione italiana.
